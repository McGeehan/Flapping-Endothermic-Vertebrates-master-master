Hat Trick, the Fun Catch Game!

This game was created live during one of our online training sessions.

The live training session can be found here:

http://unity3d.com/learn/tutorials/modules/beginner/live-training-archive/2d-catch-game-pt1

http://unity3d.com/learn/tutorials/modules/beginner/live-training-archive/2d-catch-game-pt2

http://unity3d.com/learn/tutorials/modules/beginner/live-training-archive/2d-catch-game-pt3

-

There are some small changes between the finished game in this package and the one that was created during our live training session.

Differences between the Video Sessions and this pack:

* 4.6 is not required
* Any uGUI components have been replaced with GUI text
* All uGUI components will return when 4.6 is released
* Script Names have all been updated with a prefix of HT_ for "Hat Trick" to prevent script conflicts with future projects for this pack
* The scene can be found under Example Games/Hat Trick/_Scenes/Hat Trick

-

For more learn material, please check the learn section of our website:

http://unity3d.com/learn