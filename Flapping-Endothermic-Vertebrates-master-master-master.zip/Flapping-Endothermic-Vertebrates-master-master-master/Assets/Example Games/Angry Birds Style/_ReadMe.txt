An Angry Birds Style Game

This game was created live during one of our online training sessions.

The live training session can be found here:

http://unity3d.com/learn/tutorials/modules/beginner/live-training-archive/making-angry-birds-style-game

http://unity3d.com/learn/tutorials/modules/beginner/live-training-archive/making-angry-birds-style-game-pt2

-

For more learn material, please check the learn section of our website:

http://unity3d.com/learn