
This game is based on the tutorial from Unity Japan:
http://japan.unity3d.com/developer/document/tutorial/2d-shooting-game-en/intro.html

Additional elements, including object pooling, have been added to this project.

For this game is meant to appear in a 4:3 aspect ratio. For best appearance and performance, set the game view to 4:3

-

For more learn material, please check the learn section of our website:

http://unity3d.com/learn